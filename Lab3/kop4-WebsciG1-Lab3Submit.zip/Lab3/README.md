Peter Ko
Lab 3 - Git & Bugs

Individual Assignment:

Screenshots attached for Mantis Bug Tracker

Link to Github: https://github.com/highpants/ITWS4500


--------------------------------------------------------

Group Assignment:

Description attached to README.md

Barebones Site (Heroku): https://g1websci2017.herokuapp.com/
Git Repository: https://github.com/highpants/websciG1

Screenshot attached for SSH Key addition
